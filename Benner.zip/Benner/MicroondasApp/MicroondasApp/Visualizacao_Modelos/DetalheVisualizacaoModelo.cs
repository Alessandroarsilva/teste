﻿using Prism.Commands;
using Prism.Mvvm;
using System;
using System.Collections.Generic;
using System.Linq;

namespace MicroondasApp.ViewModels
{
	public class DetailViewModel : BindableBase
	{
        public DetailViewModel()
        {

        }
	}
}
