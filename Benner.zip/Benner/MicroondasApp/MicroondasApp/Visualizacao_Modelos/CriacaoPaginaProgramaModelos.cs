﻿using MicroondasApp.Models;
using MicroondasApp.Utils;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Navigation;
using System;
using System.Collections.Generic;
using System.Linq;

namespace MicroondasApp.ViewModels
{
	public class CreateProgramPageViewModel : BindableBase
	{

        //declaracao variaveis
        private string nomePrograma;
        private string descricaoPrograma;
        private int tempoPrograma;
        private int potenciaPrograma;
        private char caracterPrograma;

        private INavigationService _navigationService;
        Program _program = new Program();
        public DelegateCommand SaveCommand { get; private set; }


        public string NameProgram
        {
            get
            {
                return nomePrograma;
            }
            set
            {
                SetProperty(ref nomePrograma, value);
            }
        }

        public string DescriptionProgram
        {
            get
            {
                return descricaoPrograma;
            }
            set
            {
                if (descricaoPrograma != value)
                {
                    descricaoPrograma = value;
                }
            }
        }

        public int TimeProgram
        {
            get
            {
                return tempoPrograma;
            }
            set
            {
                if (tempoPrograma != value)
                {
                    tempoPrograma = value;
                }
            }
        }

        public int PowerProgram
        {
            get
            {
                return potenciaPrograma;
            }
            set
            {
                if (potenciaPrograma != value)
                {
                    potenciaPrograma = value;
                }
            }
        }

        public char CharSpecial
        {
            get
            {
                return caracterPrograma;
            }
            set
            {
                if (caracterPrograma != value)
                {
                    caracterPrograma = value;
                }
            }
        }


        public CreateProgramPageViewModel(INavigationService navigationService)
        {
            _navigationService = navigationService;
            SaveCommand = new DelegateCommand(ExecuteSave);
        }

        private void ExecuteSave()
        {
            try
            {
                ValidaTempo();
            }
            catch
            {
                App.Current.MainPage.DisplayAlert("Alerta", "Tempo fora do limite", "OK");
                return;
            }
            try
            {
                ValidaPotencia();
            }
            catch
            {
                App.Current.MainPage.DisplayAlert("Alerta", "Potência fora do limite", "OK");
                return;
            }
            try
            {
                ValidaPrograma();
            }
            catch
            {
                App.Current.MainPage.DisplayAlert("Alerta", "Programa já existente", "OK");
                return;
            }
          

            DataBase.getInstance().Programs.Add(new Program(NameProgram, DescriptionProgram, TimeProgram, PowerProgram, CharSpecial));
            _navigationService.GoBackToRootAsync();
        }

        private void ValidaTempo()
        {          
            if (TimeProgram > 120)
                    throw new Exception();
            if (TimeProgram < 1)
                throw new Exception();
        }

        private void ValidaPotencia()
        {
            if (PowerProgram > 10)
                throw new Exception();
            if (PowerProgram < 1)
                throw new Exception();
        }

        private void ValidaPrograma()
        {
            var searchResults = (from a in DataBase.getInstance().Programs
                                 where a.Name == NameProgram
                                 select a).FirstOrDefault();
            if (searchResults != null)
                throw new Exception();
        }
    }
}
