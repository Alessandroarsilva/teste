﻿using MicroondasApp.Models;
using Prism.Mvvm;
using System.ComponentModel;
using System.Collections.ObjectModel;

namespace MicroondasApp.ViewModels
{
	public class HomePageViewModel : BindableBase, INotifyPropertyChanged
	{        
        public HomePageViewModel()
        {
           
        } 
	}
}
