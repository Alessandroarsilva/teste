﻿using Xamarin.Forms;

namespace MicroondasApp.Views
{
    public partial class HomePage : ContentPage
    {
        public HomePage()
        {
            InitializeComponent();
        }
    }
}
