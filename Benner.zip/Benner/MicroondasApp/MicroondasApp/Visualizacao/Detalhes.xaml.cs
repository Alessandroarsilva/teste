﻿using Xamarin.Forms;

namespace MicroondasApp.Views
{
    public partial class Detail : ContentPage
    {
        public Detail()
        {
            InitializeComponent();
        }
    }
}
