﻿using Xamarin.Forms;

namespace MicroondasApp.Views
{
    public partial class CreateProgramPage : ContentPage
    {
        public CreateProgramPage()
        {
            InitializeComponent();
        }
    }
}
