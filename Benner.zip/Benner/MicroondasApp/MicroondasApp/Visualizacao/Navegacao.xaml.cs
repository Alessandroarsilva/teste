﻿using Xamarin.Forms;

namespace MicroondasApp.Views
{
    public partial class Navigation : NavigationPage
    {
        public Navigation()
        {
            InitializeComponent();
        }
    }
}
