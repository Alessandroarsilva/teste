﻿using Xamarin.Forms;

namespace MicroondasApp.Views
{
    public partial class Master : MasterDetailPage
    {
        public Master()
        {
            InitializeComponent();
        }
    }
}