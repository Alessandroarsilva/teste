﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MicroondasApp.Models
{
    public class Controller
    {
        public bool Executando { get; set; }
    }
}
