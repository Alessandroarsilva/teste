﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MicroondasApp.Models
{
    interface IIMicroondas
    {
        void Execute(Settings Settings);
    }
}
