﻿
using System;

namespace MicroondasApp.Models
{
    public class Settings : BasePropertyChanged
    {
        private DateTime temporiazador;
        private int potencia;
        private string programa;
        private char caractere;

        public Settings()
        {
            CharHeating = '.';
        }

        public DateTime Time
        {
            get
            {
                return temporiazador;
            }           
        }

        public void AddTime(int number)
        {

            var oldTime = temporiazador;
            var minutes = temporiazador.Minute;
            var seconds = temporiazador.Second * 10 + number;

            if (seconds > 60)
            {
                minutes = seconds / 60;
                seconds = seconds % 60;
            }

            temporiazador = new DateTime(0001, 1, 1, 0, minutes, seconds);
            SetProperty(ref oldTime, temporiazador);
        }

        public void SubtraiTime()
        {

            var oldTime = temporiazador;
            var minutes = temporiazador.Minute;
            var seconds = temporiazador.Second;

            if (minutes > 0 && seconds == 0)
            {
                minutes--;
                seconds = 59;
            }
            else
            {
                seconds--;
            }

            temporiazador = new DateTime(0001, 1, 1, 0, minutes, seconds);
            SetProperty(ref oldTime, temporiazador);
        }

        public void ZerarTime()
        {
            var oldTime = temporiazador;
            temporiazador = new DateTime();
            SetProperty(ref oldTime, temporiazador);
        }

        public int Power
        {
            get
            {
                return potencia;
            }
            set
            {
                SetProperty(ref potencia, value);
            }
        }

        public string Program
        {
            get
            {
                return programa;
            }
            set
            {
                SetProperty(ref programa, value);
            }
        }

        public char CharHeating
        {
            get { return caractere; }
            set
            {
                SetProperty(ref caractere, value);
            }
        }
    }
}
