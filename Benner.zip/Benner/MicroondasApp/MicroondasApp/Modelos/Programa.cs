﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using MicroondasApp.ViewModels;


namespace MicroondasApp.Models
{
    public class Program : Settings
    {
        private string nome;
        private string descricao;
        private int tempos;

        public string Name
        {
            get { return nome; }
            set
            {
                SetProperty(ref nome, value);
            }
        }

        public int Tempo
        {
            get
            {
                return tempos;
            }
            set
            {
                SetProperty(ref tempos, value);
            }
        }

        public string Description
        {
            get { return descricao; }
            set
            {
                SetProperty(ref descricao, value);
            }
        }

        public Program(String Name, String Description, int Power, int Tempo, char CharHeating)
        {
            this.Name = Name;
            this.Description = Description;
            this.Power = Power;
            this.CharHeating = CharHeating;
            this.Tempo = Tempo;
            AddTime(Tempo);
        }

        public Program()
        {

        }

        public static ObservableCollection<Program> StartProgram()
        {
            ObservableCollection<Program> programs = new ObservableCollection<Program>();
            //incluindo os programas pre defenidos
            var 
              program = new Program("Congelados", "Descogelamento", 20, 120, '+');
              programs.Add(program);

              program = new Program("Carne", "Descogelamento de Carne", 20, 120, '+');
              programs.Add(program);

              program = new Program("Bolo", "Assar Bolor", 29, 120, '+');
              programs.Add(program);

            return programs; 
        }

    }
}
