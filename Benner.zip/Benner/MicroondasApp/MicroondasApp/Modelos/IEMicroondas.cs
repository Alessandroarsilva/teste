﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MicroondasApp.Models
{
    interface IEMicroondas
    {
        void DefinitionTime(DateTime time);
        void DefinitionPower(int power);
    }
}
